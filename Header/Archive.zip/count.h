extern int counter;
void inc_counter();

