#include "count.h"
int counter = 0;

void inc_counter()
{
  ++counter;
}
