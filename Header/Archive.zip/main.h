void runCounter(int);
struct business_entry{
    char name[30];
    char address[256];
};
typedef struct business_entry business;

